#include <stdlib.h>

int adatron(long *y, double *K, int n, double C, int maxsteps, double eps,
	    double *alpha, double *margin);
