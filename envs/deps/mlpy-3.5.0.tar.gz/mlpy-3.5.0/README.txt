==============================
mlpy - Machine Learning Python
==============================

 * Homepage: mlpy.sourceforge.net
 * Documentation: mlpy.sourceforge.net\docs
 * Project page: sourceforge.net/projects/mlpy/
